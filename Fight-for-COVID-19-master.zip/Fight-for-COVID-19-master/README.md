<h1>Fight for COVID-19</h1>
India's nationwide lockdown, has left millions of poor people unable to fulfill their basic needs. We thought that this is a crisis that requires large-scale collaboration, so we designed a website which could help these people. Because of the COVID-19 people don’t want to come outside to help because of the fear of infection. Through our website they can easily donate food, cloths, and other essentials things. In this website, people can easily give their name and the things they wants to distribute. We will collect them and help them to help poor people. E-certificate will also be provided to active participant. <br> 
 Keeping the ongoing scenario in our mind, we thought if not now, then never ! Hence this is a little step from our side in providing help to one and all.<br>
 This platform is made for helping people in need with food and other stuff. Since there are many people who want to help the needy ones especially during this pandemic time but cant due to obvious reasons. Hence we have come up with this solution that we will collect the items  from the people who genuinely want to help and will distribute them to the ones who are in dire need of that . 
Lets all come together and fight this together. We got this !
<br><br><br>
<h2>Features</h2>

- help will be given to the needy ones
- proper measures will be taken
- data will be stored securely 
- attempt of extensive donation and services 
- promoting unity 
- ensuring that no one gets left behind.
<br><br><br>

<h2>screenshots</h2 >

<img src="1.jpg" height="75%" width="75%">
<br><br>




<img src="2.jpg" height="75%" width="75%">
<br><br>




<img src="3.jpg" height="75%" width="75%">
<br><br>



<img src="4.jpg" height="75%"  width="75%">
<br><br>





<img src="5.jpg" height="75%"  width="75%">
<br><br>




<img src="6.jpg"  height="75%"  width="75%">
<br><br><br>
<h3>software used</h3><br>
1.virtual studio
<h3>language used</h3><br>
1.HTML<br>
2.CSS<br>
3.JS<br>
